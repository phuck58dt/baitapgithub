n = int(input("enter a number: "))
while n >=0 :
  print(n);
  n = n - 1;