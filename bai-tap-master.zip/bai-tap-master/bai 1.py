n1=int(input("nhap n1"))
n2=int(input("nhap n2"))
if n1>n2:
    print("n1 lơn nhat")
else:
    print("n2 lon nhat")
