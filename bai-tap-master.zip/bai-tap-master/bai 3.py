n=int(input("enter a number : "))
if n % 2 == 0:
    print ("even number");
else:
    print ("odd number");