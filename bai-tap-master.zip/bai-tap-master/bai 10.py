a="xin chao toi den tu Viet Nam"
b=a.split()
print (b)
c=" ".\
    join(b)
print (c)